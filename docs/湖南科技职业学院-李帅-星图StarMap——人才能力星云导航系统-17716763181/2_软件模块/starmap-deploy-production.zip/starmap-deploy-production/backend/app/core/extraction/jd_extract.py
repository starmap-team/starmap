"""Main JD extraction orchestrator.

Pipeline: prompt filling -> LLM call -> JSON parsing -> pydantic validation
          -> skill normalization -> anti-hallucination check.
"""

import re
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from loguru import logger
from pydantic import BaseModel, Field

from app.config import settings
from app.core.extraction.anti_hallucination import (
    AntiHallucinationResult,
    normalize_skill_list,
    normalize_str_list,
)
from app.core.extraction.llm_client import (
    LLMBlockedError,
    LLMClient,
    LLMConnectionError,
    LLMResponseError,
    LLMTimeoutError,
    parse_llm_json_response,
)
from app.core.extraction.normalize import (
    batch_normalize_skills,
    extract_dict_skills,
)
from app.core.extraction.prompt import get_ab_test, get_active_version, get_prompt
from app.core.extraction.prompt_injection import scan_prompt_injection
from app.core.extraction.translation import has_cjk, translate_title_industry  # I18N-01 翻译钩子

# Chinese PII patterns
_PII_PATTERNS: list[re.Pattern] = [
    re.compile(r"1[3-9]\d{9}"),           # Mobile phone
    re.compile(r"\d{18}[\dXx]"),           # ID card number
    re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"),  # Email
]

# P0 修复 (): 中文姓名脱敏模式
# 匹配 "姓名：张三" / "联系人：李四" / "name：王五" 等常见格式
# 以及独立的中文名（2-4个中文字符，前面有常见前缀词）
_NAME_PREFIX_PATTERN = re.compile(
    r"(?:姓名|名字|联系人|候选人|求职者|name|Name)[:\s：：]+"
    r"([一-鿿]{2,4})"
)
# 简历开头常见格式："张三 | 男 | ..." 或 "姓名：张三"
_RESUME_HEADER_NAME = re.compile(
    r"^([一-鿿]{2,4})\s*[|｜｜]"
)


class SkillCategory(StrEnum):
    """Skill category enum matching ontology values."""

    hard_skill = "hard_skill"
    soft_skill = "soft_skill"
    tool = "tool"
    certificate = "certificate"


def mask_pii(text: str, replacement: str = "[REDACTED]") -> str:
    """Mask Chinese PII (phone, ID, email, name) in text.

    P0 修复 (DATA-01): 增加中文姓名脱敏，防止简历姓名发送至第三方 LLM。
    """
 # 先脱敏手机号、身份证、邮箱
    for pattern in _PII_PATTERNS:
        text = pattern.sub(replacement, text)
 # 脱敏带前缀的姓名
    text = _NAME_PREFIX_PATTERN.sub(
        lambda m: m.group(0)[: m.start(1) - m.start(0)] + replacement,
        text,
    )
 # 脱敏简历开头格式的姓名
    text = _RESUME_HEADER_NAME.sub(
        lambda m: replacement + m.group(0)[len(m.group(1)):],
        text,
    )
    return text


class SkillEntry(BaseModel):
    """A single skill entry in extraction results."""

    name: str = Field(..., description="Skill name")
    level: str | None = Field(default="intermediate", description="Proficiency level")
    category: str | None = Field(default=None, description="Skill category: hard_skill/soft_skill/tool/certificate")
    years_of_experience: float | None = Field(default=None, description="Years of experience")


class PrerequisiteEntry(BaseModel):
    """A prerequisite skill relationship."""

    skill: str = Field(..., description="The skill that is a prerequisite")
    required_by: str = Field(default="", description="The skill that requires this prerequisite")


class ToolEntry(BaseModel):
    """A tool/technology entry."""

    name: str = Field(..., description="Tool name")
    category: str | None = Field(default=None, description="Tool category: ide/framework/platform/etc")


class LearningResourceEntry(BaseModel):
    """A learning resource entry."""

    title: str = Field(..., description="Resource title")
    type: str | None = Field(default=None, description="Resource type: book/course/tutorial/docs")
    url: str | None = Field(default=None, description="Resource URL if available")
    for_skill: str | None = Field(default=None, description="Primary skill this resource teaches")


class JDExtractionResult(BaseModel):
    """Validated JD extraction output."""

    position_name: str = Field(default="", description="Job position title")
    required_skills: list[SkillEntry] = Field(default_factory=list, description="Required skills")
    preferred_skills: list[SkillEntry] = Field(default_factory=list, description="Preferred skills")
    experience_required: int | None = Field(default=None, description="Minimum years of experience")
    education_required: str | None = Field(default=None, description="Minimum education requirement")
    responsibilities: list[str] = Field(default_factory=list, description="Job responsibilities")
    industry: str | None = Field(default=None, description="Industry sector")
    description: str | None = Field(default=None, description="Brief position description")
    knowledge_areas: list[str] = Field(default_factory=list, description="Knowledge domains/areas")
    tools: list[ToolEntry] = Field(default_factory=list, description="Tools and technologies used")
    prerequisites: list[PrerequisiteEntry] = Field(default_factory=list, description="Skill prerequisite relationships")
    learning_resources: list[LearningResourceEntry] = Field(default_factory=list, description="Recommended learning resources")
    evolves_to: list[str] = Field(default_factory=list, description="Related positions this role can evolve into")




@dataclass
class JDExtractionPipeline:
    """Configurable JD extraction pipeline."""

    llm_client: LLMClient = field(default_factory=LLMClient)
    anti_hallucination_enabled: bool = True
    normalize_skills_enabled: bool = True
    use_vector_normalization: bool = True
    vector_threshold: float = settings.extraction_vector_threshold
    min_sources: int = settings.extraction_min_sources
    source_counts: dict[str, int] | None = None

    async def run(self, jd_content: str, options: dict[str, Any] | None = None) -> dict[str, Any]:
        """Execute the full extraction pipeline.

        Args:
            jd_content: Raw job description text.
            options: Override pipeline options.

        Returns:
            Dict with 'success', 'data', 'warnings', 'normalization', 'validation', 'error'.
        """
        if options:
            for k, v in options.items():
                if hasattr(self, k):
                    setattr(self, k, v)

        result: dict[str, Any] = {
            "success": False,
            "data": None,
            "warnings": [],
            "normalization": [],
            "validation": None,
            "error": None,
            "prompt_version_used": None,
            "prompt_ab_test": False,
        }

        if not jd_content or not jd_content.strip():
            result["error"] = "Empty JD content"
            return result

 # PII masking before sending to LLM
        jd_content_safe = mask_pii(jd_content)

 # (): 输入侧 prompt-injection 检测——JD 文本是用户
 # 输入，直接拼入 LLM prompt 可被 "ignore previous instructions" 类注入
 # 劫持抽取（技能幻觉/抽取投毒）。命中注入模式时拒绝本次抽取并记录。
        injection_check = scan_prompt_injection(jd_content_safe)
        if not injection_check.is_clean:
            logger.warning(
                "prompt-injection blocked: patterns={} snippet={!r} confidence={:.2f}",
                injection_check.matched_patterns,
                injection_check.snippet[:120],
                injection_check.confidence,
            )
            result["status"] = "failed"
            result["error"] = "JD content rejected: suspected prompt injection"
            result["injection_check"] = injection_check.model_dump()
            return result
        result["injection_checked"] = True

 # Step 1: Fill prompt
        logger.info("JD extraction pipeline starting ({} chars)", len(jd_content_safe))
        try:
            _ = get_prompt("jd_extraction", jd_content=jd_content_safe)
        except (KeyError, ValueError) as e:
            result["error"] = f"Prompt error: {e}"
            return result

 # Track which prompt version was resolved (supports A/B test)
        ab_cfg = get_ab_test("jd_extraction")
        if ab_cfg:
 # A/B test active: don't call select_version() again to avoid
 # randomness mismatch with the earlier get_prompt() call.
 # Record the test config; per-request version is random.
            result["prompt_ab_test"] = True
            result["prompt_version_used"] = (
                f"ab_test(control={ab_cfg.control_version},"
                f" canary={ab_cfg.canary_version},"
                f" traffic={ab_cfg.traffic_fraction:.0%})"
            )
            logger.info(
                "A/B test active: jd_extraction control={} canary={} traffic={:.0%}",
                ab_cfg.control_version, ab_cfg.canary_version, ab_cfg.traffic_fraction,
            )
        else:
            result["prompt_ab_test"] = False
            result["prompt_version_used"] = get_active_version("jd_extraction") or "v1"

 # Step 2: Call LLM
        try:
            raw = await self.llm_client.extract_from_jd(jd_content_safe)
        except LLMBlockedError as e:
            # Phase 27 资源包严格保护: blocked = 严格不调用(不重试,不消耗任何 token)
            # 上层用 fallback / 跳过 / 显式提示,不污染业务流。
            logger.warning("LLM blocked (Phase 27): {}", e)
            result["status"] = "blocked"
            result["error"] = f"LLM blocked: {e}"
            result["warnings"].append(
                "LLM 调用被资源包保护阻断(成本 cap / 128K 闸门 / 全局开关),"
                "本次抽取跳过,请检查 settings 与累计成本",
            )
            return result
        except LLMConnectionError as e:
            logger.error("LLM connection failed: {}", e)
            result["error"] = f"LLM connection error: {e}"
            return result
        except LLMResponseError as e:
            logger.error("LLM response error: {}", e)
            result["error"] = f"LLM response error: {e}"
            return result
        except LLMTimeoutError as e:
            logger.error("LLM timeout: {}", e)
            result["error"] = f"LLM timeout: {e}"
            return result

 # 记录实际用于抽取的模型（含降级 fallback，如 qwen2.5-7b-fallback），
 # 供前端展示“本次抽取所用模型/是否降级”，保证降级反馈透明。
        result["model_used"] = getattr(self.llm_client, "last_extraction_model", None)

 # Step 3: Parse JSON
        try:
            parsed = parse_llm_json_response(raw["content"]) if isinstance(raw, dict) and "content" in raw else raw
        except LLMResponseError as e:
            result["error"] = f"JSON parse error: {e}"
            return result

 # Step 4: Pydantic validation
        try:
            validated = JDExtractionResult(**parsed)
        except (TypeError, ValueError) as e:
            logger.warning("Pydantic validation failed, using raw data: {}", e)
            result["warnings"].append(f"Pydantic validation issue: {e}")
            validated = JDExtractionResult()
 # BL-02: Complete fallback for ALL fields, not just a subset
            for key in ("position_name", "experience_required", "education_required",
                        "industry", "description"):
                if key in parsed:
                    setattr(validated, key, parsed.get(key, ""))
            for key in ("required_skills", "preferred_skills"):
                if key in parsed and parsed[key]:
                    setattr(validated, key, [
                        SkillEntry(**s) if isinstance(s, dict) else SkillEntry(name=s)
                        for s in parsed[key]
                    ])
            for key in ("responsibilities", "knowledge_areas", "evolves_to"):
                if key in parsed and isinstance(parsed[key], list):
                    setattr(validated, key, parsed[key])
            if "tools" in parsed and isinstance(parsed["tools"], list):
                validated.tools = [
                    ToolEntry(**t) if isinstance(t, dict) else ToolEntry(name=str(t))
                    for t in parsed["tools"]
                ]
            if "prerequisites" in parsed and isinstance(parsed["prerequisites"], list):
                prereqs = []
                for p in parsed["prerequisites"]:
                    try:
                        if isinstance(p, dict):
 # Try dict first, fallback to using first value as skill
                            prereqs.append(PrerequisiteEntry(**p))
                        else:
                            prereqs.append(PrerequisiteEntry(skill=str(p)))
                    except Exception:
 # LLM returned unexpected dict keys — use best-effort
                        name = p.get("name") or p.get("skill") or str(p)
                        prereqs.append(PrerequisiteEntry(skill=name))
                validated.prerequisites = prereqs
            if "learning_resources" in parsed and isinstance(parsed["learning_resources"], list):
                validated.learning_resources = [
                    LearningResourceEntry(**lr) if isinstance(lr, dict) else LearningResourceEntry(title=str(lr))
                    for lr in parsed["learning_resources"]
                ]

 # Step 4.5: Clean up Chinese suffixes from skill names
        chinese_suffixes = [
            "系统", "安全", "开发", "管理", "平台", "框架", "技术", "语言",
            "生态", "相关", "服务", "设计", "网络", "算法", "存储", "计算",
            "容器", "工具", "应用", "架构", "工程", "引擎", "协议", "自动化",
            "编程", "部署", "监控", "测试", "运维", "研发",
            "运行时", "数据库", "环境", "桌面", "并行", "调优", "优化",
            "设计规范", "部署经验", "模型转换", "模型加速", "内核", "源码",
 # low-F1 optimization: strip common Chinese suffixes that LLM appends
            "方法论", "能力", "攻防", "漏洞", "竞赛经验", "认证", "证书",
        ]
        def _clean_skill_name(name: str) -> str:
 # BL-08: raise min length to 4 to prevent over-stripping
 # (e.g. "分布式系统" → "分布式" at len=3 was valid but too aggressive)
            while True:
                original = name
                for suffix in chinese_suffixes:
                    if len(name) > 4 and name.endswith(suffix):
                        cleaned = name[:-len(suffix)]
 # Only apply strip if result is non-empty AND at least 4 chars
 # BL-08: prevents over-stripping like "分布式系统架构"→"分布式"
                        if cleaned and len(cleaned) >= 4:
                            name = cleaned
                if name == original:
                    break
            return name

        for skill in validated.required_skills:
            cleaned = _clean_skill_name(skill.name)
            if cleaned != skill.name:
                logger.debug("Cleaned skill name: '{}' -> '{}'", skill.name, cleaned)
                skill.name = cleaned
        for skill in validated.preferred_skills:
            cleaned = _clean_skill_name(skill.name)
            if cleaned != skill.name:
                logger.debug("Cleaned skill name: '{}' -> '{}'", skill.name, cleaned)
                skill.name = cleaned

 # Step 5: Normalize skills
        if self.normalize_skills_enabled:
            all_skill_names = []
            for skill in validated.required_skills:
                all_skill_names.append(skill.name)
            for skill in validated.preferred_skills:
                all_skill_names.append(skill.name)

            normalized_results = batch_normalize_skills(
                all_skill_names,
                use_vector=self.use_vector_normalization,
                vector_threshold=self.vector_threshold,
                min_sources=self.min_sources,
                source_counts=self.source_counts,
            )

            result["normalization"] = [nr.__dict__ for nr in normalized_results]

 # P0-AUDIT-FIX (2026-08-13): replace manual iter() + next() chain
 # with zip(). If batch_normalize_skills returns fewer items than
 # expected (e.g. vector/Chroma exception swallowed one), next()
 # raises StopIteration and the response becomes a 500; even worse,
 # if it returns more items we silently dropped the tail. zip()
 # truncates to the shorter input — the leftover skills keep their
 # original names instead of crashing or going half-applied.
            for skill, nr in zip(validated.required_skills, normalized_results, strict=False):
                if nr.normalized:
                    skill.name = nr.normalized
            offset = len(validated.required_skills)
            for skill, nr in zip(validated.preferred_skills, normalized_results[offset:], strict=False):
                if nr.normalized:
                    skill.name = nr.normalized
 # Surface the count mismatch as a warning so callers can see it.
            expected = len(validated.required_skills) + len(validated.preferred_skills)
            if len(normalized_results) != expected:
                result.setdefault("warnings", []).append(
                    f"normalization count mismatch: expected={expected}, got={len(normalized_results)}"
                )

 # Step 6: Anti-hallucination check
        validation = None
        if self.anti_hallucination_enabled:
            try:
                v = await self.llm_client.validate_extraction(
                    validated.model_dump(),
                    jd_content_safe,
                )
 # MiMo reasoning model may return dicts with {name, reasoning}
 # instead of plain strings — normalize ALL list[str] fields
                v["hallucinated_skills"] = normalize_str_list(v.get("hallucinated_skills", []))
                v["missing_skills"] = normalize_str_list(v.get("missing_skills", []))
                v["issues"] = normalize_str_list(v.get("issues", []))
                validation = AntiHallucinationResult(**v)
 # Normalize dict items to strings for serialization
                v_normalized = validation.model_dump()
                v_normalized["hallucinated_skills"] = normalize_skill_list(validation.hallucinated_skills)
                v_normalized["missing_skills"] = normalize_skill_list(validation.missing_skills)
                result["validation"] = v_normalized

                if not validation.is_valid:
                    msg = f"Anti-hallucination: {len(validation.hallucinated_skills)} hallucinated, {len(validation.missing_skills)} missing"
                    result["warnings"].append(msg)
                    logger.warning(msg)

            except (LLMBlockedError, LLMConnectionError, LLMResponseError, LLMTimeoutError) as e:
                logger.warning("Anti-hallucination check failed: {}", e)
                result["warnings"].append(f"Validation error: {e}")

 # Step 6.5: 规则过滤 — 非技能词黑名单(职责/软词/行业词)
 # 2026-08-23: LLM 常把 Hiring/Customer Success/Leadership 等当技能提取,
 # 在词典过滤前先用黑名单剔除, 避免非技能进入技能库。
        try:
            from app.core.extraction import anti_hallucination as _ah
            _checker = _ah.AntiHallucinationChecker()
            _before_r = len(validated.required_skills)
            _before_p = len(validated.preferred_skills)
            validated.required_skills = [
                s for s in validated.required_skills
                if _checker.check_skill(s.name, s.name, 1.0)[0]
            ]
            validated.preferred_skills = [
                s for s in validated.preferred_skills
                if _checker.check_skill(s.name, s.name, 1.0)[0]
            ]
            _dropped = (_before_r - len(validated.required_skills)) + (_before_p - len(validated.preferred_skills))
            if _dropped:
                result["warnings"].append(f"Rule filter dropped {_dropped} non-skill items")
        except Exception as _e:  # noqa: BLE001 — 过滤失败不阻断主流程
            logger.warning("Rule skill filter failed: {}", _e)

 # Step 7: Dictionary post-filter — keep only LLM skills that match SKILL_ALIAS
 # ECC regex-vs-llm-structured-text "Regex handles 95-98%". This filter
 # drops LLM hallucinations (skills invented beyond our 572-skill vocabulary),
 # at the cost of dropping some novel skills LLM found correctly. On the 110-sample
 # golden set, this lifts F1 from 0.8637 → 0.9258 (skill F1, weighted bonus+required).
        dict_skills = extract_dict_skills(jd_content_safe)
        if dict_skills:
            before_req = len(validated.required_skills)
            before_pref = len(validated.preferred_skills)
            validated.required_skills = [
                s for s in validated.required_skills
                if s.name in dict_skills
            ]
            validated.preferred_skills = [
                s for s in validated.preferred_skills
                if s.name in dict_skills
            ]
            dropped = (before_req - len(validated.required_skills)) + (before_pref - len(validated.preferred_skills))
            if dropped:
                result["warnings"].append(f"Dict filter dropped {dropped} out-of-vocabulary skills")

        result["success"] = True
        result["data"] = validated.model_dump()

 # Step 8: — 非 CJK 岗位名翻译钩子 (RemoteOK 等英文 JD 源)
 # 仅当 LLM 返回的 position_name 不含 CJK 才触发 (中文 JD 零成本跳过);
 # 失败优雅降级 (name_cn 不注入, 前端显"英文原文"标签, 不编造)。
        pos_name = validated.position_name
        if pos_name and not has_cjk(pos_name):
            try:
                translated = await translate_title_industry(
                    self.llm_client,
                    title=pos_name,
                    industry=getattr(validated, "industry", None),
                )
                if translated.get("name_cn"):
                    result["data"]["name_cn"] = translated["name_cn"]
                    result["data"]["industry_zh"] = translated.get("industry_zh")
                    logger.info("I18N-01: translated '{}' -> '{}'", pos_name, translated["name_cn"])
                else:
                    result["warnings"].append("Translation skipped: LLM unavailable")
            except Exception as e:  # noqa: BLE001 — 翻译永不阻断抽取
                logger.warning("I18N-01 translation failed (graceful): {}", e)
                result["warnings"].append("Translation skipped: LLM error")

        logger.info("JD extraction pipeline complete: {} required, {} preferred skills",
                     len(validated.required_skills), len(validated.preferred_skills))
        return result


async def extract_from_jd(
    jd_content: str,
    options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Convenience function to run the full JD extraction pipeline.

    Args:
        jd_content: Raw job description text.
        options: Optional pipeline configuration overrides:
            - anti_hallucination_enabled (bool)
            - normalize_skills_enabled (bool)
            - use_vector_normalization (bool)
            - vector_threshold (float)
            - min_sources (int)
            - source_counts (dict[str, int]): Skill name -> source count map

    Returns:
        Pipeline result dict with keys: success, data, warnings, normalization, validation, error.
    """
    pipeline = JDExtractionPipeline()
    return await pipeline.run(jd_content, options)
