"""PIPE-03 (c): celery-worker 启动一次性 bootstrap。

检测 PIPELINE_BOOTSTRAP=true → 延迟 30s 后入队一次完整 pipeline run。
仅一次性（不循环）。在 worker 进程内同步触发 executor.trigger_and_start。

读取走 settings.pipeline_bootstrap（受 config.py 生产 fail-fast 守卫保护）：
生产环境下即使 .env.production 误开 PIPELINE_BOOTSTRAP=true，进程启动即拒。
"""
from __future__ import annotations

import asyncio
import threading

from loguru import logger

from app.config import settings

BOOTSTRAP_DELAY_SECONDS = 30


def schedule_bootstrap_if_enabled() -> None:
    """Celery worker 启动时调用 — 仅在 PIPELINE_BOOTSTRAP=true 时入队一次。

    使用 threading.Timer 而非 asyncio，避免在 worker 主循环阻塞 30 秒。
    错误吞掉并 logger.exception（不影响 worker 启动）。
    """
    if not settings.pipeline_bootstrap:
        return

    logger.info(
        "PIPELINE_BOOTSTRAP=true (env); will enqueue a single pipeline run in {}s",
        BOOTSTRAP_DELAY_SECONDS,
    )

    def _fire() -> None:
        try:
            from app.core.pipeline.executor import trigger_and_start
 # fix (functional-review 2026-08-13): 此前传 run_type="bootstrap"，
 # 而 create_run 只校验 {"full","incremental"} → ValueError 被吞掉，
 # PIPELINE_BOOTSTRAP=true 时首启种子管线永远建不出来。bootstrap 语义
 # 即全量首灌，改用 "full"。
            run = asyncio.run(
                trigger_and_start(run_type="full", selected_stages=None)
            )
            logger.info(
                "Bootstrap pipeline run dispatched (id={}, status={})",
                run.id, run.status,
            )
        except Exception:
            logger.exception("Bootstrap pipeline trigger failed")

    t = threading.Timer(BOOTSTRAP_DELAY_SECONDS, _fire)
    t.daemon = True
    t.start()


__all__ = ["schedule_bootstrap_if_enabled", "BOOTSTRAP_DELAY_SECONDS"]
