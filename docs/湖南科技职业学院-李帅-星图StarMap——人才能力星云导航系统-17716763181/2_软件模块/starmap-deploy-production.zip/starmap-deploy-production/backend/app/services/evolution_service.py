"""Evolution service layer — business logic extracted from evolution.py API routes.

P1-4 fix: routes should be thin; heavy orchestration (EmergenceFinder, Cypher queries,
SQL joins, CII calculations) belongs here.
"""

from __future__ import annotations

import json
from typing import Any

import sqlalchemy as sa
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.evolution.causal_inference import (
    skill_position_associations,  # noqa: F401 — §7.6 轻量版 re-export (路由经 service 访问 core)
)
from app.core.evolution.emergence_finder import EmergenceFinder
from app.core.evolution.timeseries_loader import load_skill_timeseries_data
from app.core.evolution.trust_scorer import (
    LOW_TRUST_THRESHOLD,  # noqa: F401 — 低信任度阈值 re-export (路由经 service 访问 core)
)
from app.core.evolution.write_back import (  # noqa: F401 — 审核即生效写回 re-export (路由经 service 访问 core)
    write_back_changelog_row,
)
from app.core.matching.constants import SENIOR_KEYWORDS  # noqa: F401 — 职级关键词 re-export (路由经 service 访问 core)
from app.models.extraction_models import PositionRecord, PositionSkillRelation, SkillRecord


def _build_signals_by_name(report: Any) -> dict[str, Any]:
    """Build a lookup dict from EmergenceFinder report signals."""
    signals_by_name: dict[str, Any] = {}
    for s in report.emerging + report.rising + report.declining:
        signals_by_name.setdefault(s.skill_name, s)
    for s in report.stable:
        signals_by_name.setdefault(s.skill_name, s)
    return signals_by_name


def _calculate_cii_points(data: dict[str, Any]) -> list[float]:
    """Normalize skill frequencies to CII scale (baseline = mean of first half)."""
    all_freqs = list(data["frequencies"])
    if data.get("current"):
        all_freqs.append(data["current"])

    if len(all_freqs) >= 2:
        half = max(1, len(all_freqs) // 2)
        baseline = sum(all_freqs[:half]) / half
        return [(f / baseline * 100) if baseline > 0 else 100.0 for f in all_freqs]
    return [100.0]


async def build_evolution_trends(
    session: AsyncSession,
    *,
    days: int = 90,
) -> list[dict[str, Any]]:
    """Build evolution trend items for the /evolution/trends endpoint.

    Returns a list of dicts ready to be unpacked into EvolutionTrend models.
    """
    skill_data = await load_skill_timeseries_data(session, days=days)

    if not skill_data:
        logger.info("No timeseries data found for trends in the last {} days", days)
        return []

 # Run emergence detection
    finder = EmergenceFinder()
    report = finder.scan(skill_data)
    signals_by_name = _build_signals_by_name(report)

 # Load position relations
    rel_stmt = (
        sa.select(SkillRecord.name, PositionRecord.name)
        .select_from(SkillRecord)
        .outerjoin(PositionSkillRelation, PositionSkillRelation.skill_id == SkillRecord.id)
        .outerjoin(PositionRecord, PositionRecord.id == PositionSkillRelation.position_id)
    )
    rel_rows = (await session.execute(rel_stmt)).all()
    skill_positions: dict[str, list[str]] = {}
    for skill_name, pos_name in rel_rows:
        if skill_name:
            skill_positions.setdefault(skill_name, [])
            if pos_name and pos_name not in skill_positions[skill_name]:
                skill_positions[skill_name].append(pos_name)

 # Build trend items — ALL skills (no [:20] silent truncation: the overview
 # table + CII chart must reflect the full trend set the user sees in KPI)
    items: list[dict[str, Any]] = []
    for name, data in skill_data.items():
        signal = signals_by_name.get(name)
        trend = signal.level.value if signal else "stable"
 # 修复 Pydantic ge=0 校验：负 z_score 会使 confidence 越界，正确 clamp 到 [0, 1]
        if signal:
            confidence = max(0.0, min(1.0, 0.5 + signal.z_score / 10))
        else:
            confidence = 0.5
        cii_points = _calculate_cii_points(data)

        items.append(
            {
                "skill_name": name,
                "trend": trend,
                "confidence": round(confidence, 3),
                "points": [round(p, 1) for p in cii_points],
                "related_positions": skill_positions.get(name, []),
            }
        )

    return items


async def build_evolution_kpi(
    session: AsyncSession,
    *,
    days: int = 90,
) -> dict[str, Any]:
    """Build the 4-KPI row for the evolution dashboard (D-11).

    - emerging_count: number of emerging+rising skills — SAME full-history
      emergence scan as /evolution/emerging-alerts, so the KPI matches the
      visible 预警表 (previously a 90 天窗口 scan → 8 vs 11 口径漂移).
    - trust_mean:     real aggregate avg(EvolutionChangelog.trust_score)
    - cii_mean:       mean of each skill's latest CII point over the days
      window (matches the 趋势概览 chart), baseline 100 口径.
    - alert_count:    non-stable signals count (emerging + rising + declining)
      from the SAME full-history scan as the 预警表.

    Empty data returns zero values, never fabricated estimates (D-12).
    """
    from app.models.evolution_models import EvolutionChangelog

 # 1/4. Emergence-derived KPIs — full-history scan (same as emerging-alerts)
    full_skill_data = await load_skill_timeseries_data(session)
    emerging_count = 0
    alert_count = 0
    if full_skill_data:
        finder = EmergenceFinder()
        report = finder.scan(full_skill_data)
        emerging_count = len(report.emerging) + len(report.rising)
        alert_count = len(report.emerging) + len(report.rising) + len(report.declining)

 # 2. Trust mean — real aggregate over the changelog table (: no placeholder)
    trust_result = await session.execute(
        sa.select(sa.func.avg(EvolutionChangelog.trust_score))
    )
    trust_value = trust_result.scalar_one()
    # 2026-08-21 (debug 修复): 空表时返回 None（前端显示"—"）而非 0.0 ——
    # 用户看到"信任均值 0%"误以为评分全为 0，实为 changelog 无记录。
    trust_mean = round(float(trust_value), 3) if trust_value is not None else None

 # 3. CII mean — days window (matches the 趋势概览 chart), avg of last points
    skill_data = await load_skill_timeseries_data(session, days=days)
    cii_last_points: list[float] = []
    for data in skill_data.values():
        points = _calculate_cii_points(data)
        if points:
            cii_last_points.append(points[-1])
    cii_mean = round(sum(cii_last_points) / len(cii_last_points), 1) if cii_last_points else 0.0

 # D-cross: 与 /quality 平均信任度对照口径（Neo4j Skill.trust_score 实时均值）
 # 复用 quality_service.avg_skill_trust 共享指标模块，避免两处口径漂移
    from app.services.quality_service import avg_skill_trust
    try:
        trust_neo4j_skill = round(float(await avg_skill_trust()), 3)
    except Exception:
        trust_neo4j_skill = 0.0

    return {
        "emerging_count": emerging_count,
        "trust_mean": trust_mean,
        "trust_mean_neo4j_skill": trust_neo4j_skill,
        "cii_mean": cii_mean,
        "alert_count": alert_count,
        "days": days,
    }


async def build_evolution_paths(
    session: AsyncSession,
    *,
    position: str | None = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """Build evolution path entries from PostgreSQL (fallback when Neo4j unavailable).

    If *position* is given, filter to paths involving that position.
    """
    from app.models.evolution_models import EvolutionPath

    stmt = sa.select(EvolutionPath)
    if position:
        stmt = stmt.where((EvolutionPath.source_position == position) | (EvolutionPath.target_position == position))
    stmt = stmt.order_by(EvolutionPath.similarity.desc()).limit(limit)

    result = await session.execute(stmt)
    records = result.scalars().all()

    return [
        {
            "id": str(r.id),
            "source_position": r.source_position,
            "target_position": r.target_position,
            "similarity": r.similarity,
            "evidence_count": r.evidence_count,
            "skill_overlap": r.skill_overlap or [],
            "key_gaps": r.key_gaps or [],
            "trust_score": r.trust_score,
            "trend": "stable",
        }
        for r in records
    ]


async def build_emerging_skills(
    session: AsyncSession,
    *,
    level: str | None = None,
) -> list[dict[str, Any]]:
    """Build emerging skill items from timeseries data."""
    skill_data = await load_skill_timeseries_data(session)

    if not skill_data:
        return []

    finder = EmergenceFinder()
    report = finder.scan(skill_data)

    signals = report.emerging + report.rising
    if level:
        signals = [s for s in signals if s.level.value == level]

    return [
        {
            "skill_name": s.skill_name,
            "level": s.level.value,
            "z_score": s.z_score,
            "current_frequency": s.current_frequency,
            "mean_frequency": s.mean_frequency,
            "source_count": s.source_count,
            "positions": s.positions,
        }
        for s in signals
    ]


async def discover_emerging_positions(
    session: AsyncSession,
    threshold: float = 0.5,
) -> dict[str, Any]:
    """模块A 新岗位发现：涌现技能 → 岗位画像交叉 → 候选新兴岗位。

    赛项要求"识别市场上萌芽/兴起的新岗位并生成岗位定义"。EmergenceFinder
    只做技能级发现（z-score），本函数在其之上做岗位级聚合：对每个已审核
    岗位统计其 required 技能中属于涌现/上升技能的比例，占比 >= threshold
    的岗位标记为"新兴演化候选"，附带岗位定义字段。

    返回:
        {"status", "candidates": [{position, industry_scenario, emerging_skills,
           emerging_ratio, definition}], "analyzed_positions"}
    """
    skill_data = await load_skill_timeseries_data(session)
    if not skill_data:
        return {
            "status": "insufficient_data",
            "candidates": [],
            "analyzed_positions": 0,
            "message": "时序数据不足，请先执行管线以生成技能频率统计",
        }

    finder = EmergenceFinder()
    report = finder.scan(skill_data)
    emerging_names = {s.skill_name for s in report.emerging + report.rising}

    # 岗位 → required 技能名
    rows = (
        await session.execute(
            sa.select(
                PositionRecord.name,
                SkillRecord.name.label("skill_name"),
            )
            .select_from(PositionSkillRelation)
            .join(PositionRecord, PositionRecord.id == PositionSkillRelation.position_id)
            .join(SkillRecord, SkillRecord.id == PositionSkillRelation.skill_id)
            .where(PositionSkillRelation.requirement_type == "required")
            .where(PositionRecord.review_status == "approved")
        )
    ).all()
    pos_skills: dict[str, set[str]] = {}
    for name, skill_name in rows:
        pos_skills.setdefault(name, set()).add(skill_name)

    candidates: list[dict[str, Any]] = []
    for pos, skills in pos_skills.items():
        hit = skills & emerging_names
        if not hit:
            continue
        ratio = round(len(hit) / len(skills), 3) if skills else 0.0
        if ratio >= threshold:
            candidates.append({
                "position": pos,
                "industry_scenario": None,  # 典型行业应用场景（抽取阶段补全）
                "emerging_skills": sorted(hit),
                "emerging_ratio": ratio,
                "definition": {
                    "position_name": pos,
                    "required_skills": sorted(skills),
                    "emerging_required": sorted(hit),
                },
            })

    # 2026-08-25: mypy 修复 —— dict 值类型不确定时显式 float()，避免
    # "Unsupported operand type for unary -" (CI 门禁)
    candidates.sort(key=lambda c: -float(c["emerging_ratio"]))
    return {
        "status": "completed" if candidates else "no_candidates",
        "candidates": candidates,
        "analyzed_positions": len(pos_skills),
        "threshold": threshold,
        "message": f"扫描 {len(pos_skills)} 个已审核岗位，发现 {len(candidates)} 个新兴演化候选",
    }


async def generate_position_definitions(
    candidates: list[dict[str, Any]],
    top_n: int = 10,
) -> dict[str, Any]:
    """A3（issue #87/#99）: 为新兴候选岗位生成五要素定义的缺失字段。

    赛项要求岗位定义包含"岗位名称、核心职责、必备技能、加分技能、典型行业
    应用场景"。discover_emerging_positions 已产出名称/必备技能/涌现技能
    骨架；本函数取 emerging_ratio Top-N 候选，经 LLM（默认 qwen-plus，
    走 call_llm_with_fallback 统一入口：Redis 7 天响应缓存 + 成本闸门 +
    128K 输入闸门）补齐 industry_scenario / core_responsibilities /
    bonus_skills / summary 四个字段。

    fail-soft（沿 D-06）：单岗位 LLM 失败/解析失败仅记 warning，该岗位
    字段保持 None，绝不阻断 discover 主流程。

    Args:
        candidates: discover_emerging_positions().candidates（已按 ratio 降序）。
        top_n: 最多生成的岗位数（成本护栏，默认 10）。

    Returns:
        {"generated": int, "failed": int, "warnings": list[str], "candidates": candidates}
    """
    warnings: list[str] = []
    generated = 0
    failed = 0
    targets = candidates[: max(1, int(top_n))]

    # 延迟 import：与模块其他 LLM 调用点一致，避免服务层加载即拉起客户端依赖链
    from app.core.extraction.llm_client import call_llm_with_fallback, parse_llm_json_response
    from app.core.extraction.prompt import get_prompt

    for cand in targets:
        pos = str(cand.get("position") or "")
        if not pos:
            continue
        definition = cand.setdefault("definition", {})
        prompt = get_prompt(
            "position_definition",
            position_name=pos,
            required_skills=json.dumps(cand.get("definition", {}).get("required_skills", []), ensure_ascii=False),
            emerging_skills=json.dumps(cand.get("emerging_skills", []), ensure_ascii=False),
        )
        try:
            resp = await call_llm_with_fallback(prompt)
            payload = parse_llm_json_response(resp.get("content", ""))

            scenario = payload.get("industry_scenario")
            responsibilities = payload.get("core_responsibilities")
            bonus = payload.get("bonus_skills")
            summary = payload.get("summary")

            # 字段校验：类型不符视为失败，不回填脏数据
            if not isinstance(scenario, str) or not scenario.strip():
                raise ValueError(f"industry_scenario invalid for {pos!r}")
            if not isinstance(responsibilities, list) or not responsibilities:
                raise ValueError(f"core_responsibilities invalid for {pos!r}")
            if not isinstance(bonus, list):
                raise ValueError(f"bonus_skills invalid for {pos!r}")

            cand["industry_scenario"] = scenario.strip()
            definition["industry_scenario"] = scenario.strip()
            definition["core_responsibilities"] = [str(x).strip() for x in responsibilities if str(x).strip()]
            definition["bonus_skills"] = [str(x).strip() for x in bonus if str(x).strip()]
            if isinstance(summary, str) and summary.strip():
                definition["summary"] = summary.strip()
            generated += 1
        except Exception as exc:  # noqa: BLE001 — fail-soft（D-06）
            failed += 1
            warnings.append(f"definition_generation: {pos}: {type(exc).__name__}: {exc}")
            logger.warning("A3 definition generation failed for {!r}: {}", pos, exc)

    return {"generated": generated, "failed": failed, "warnings": warnings, "candidates": candidates}


def build_change_explanation(record: Any) -> str:
    """模块B 更新说明：规则模板派生自然语言变更说明（不依赖 LLM）。

    赛项要求能力变更"提供更新说明及数据源"。根据 change_type 与
    evidence_json（mention_count_old/new、source_count、factors）生成
    可读的中文说明，数据源引用 mention_count/source_count 统计依据。
    """
    evidence = getattr(record, "evidence_json", None) or {}
    mention_old = evidence.get("mention_count_old")
    mention_new = evidence.get("mention_count_new")
    source_count = evidence.get("source_count")
    ctype = getattr(record, "change_type", "") or ""
    skill = getattr(record, "skill_name", "") or ""
    position = getattr(record, "position_name", "") or "该岗位"

    source_ref = ""
    if source_count:
        source_ref = f"（数据源：{source_count} 个独立 JD 来源"
        if mention_old is not None and mention_new is not None:
            source_ref += f"，提及次数 {mention_old}→{mention_new}"
        source_ref += "）"

    if ctype == "added_required":
        return f"「{position}」新增必备技能「{skill}」{source_ref}：市场 JD 对该技能的需求占比上升，已提升为核心要求。"
    if ctype == "added_preferred":
        return f"「{position}」新增加分技能「{skill}」{source_ref}：更多 JD 将其列为优先项。"
    if ctype == "removed":
        return f"「{position}」移除技能「{skill}」{source_ref}：JD 提及显著下降或已不再要求。"
    if ctype == "promoted":
        return f"「{position}」技能「{skill}」由加分项提升为必备项{source_ref}：需求增长使其成为硬性要求。"
    if ctype == "demoted":
        return f"「{position}」技能「{skill}」由必备项降为加分项{source_ref}：需求减弱或竞争性下降。"
    return f"「{position}」技能「{skill}」状态更新（{ctype}）{source_ref}。"
